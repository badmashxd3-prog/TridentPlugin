# God Trident - Resource Pack

Is resource pack me God Trident ka **custom 3D model + animated glowing texture** hai - vanilla trident se bilkul alag, ek modern deadly-weapon jaisa look (dark gunmetal shaft + pulsing red/orange energy prongs).

## Kya hai isme

- `assets/minecraft/models/item/god_trident.json` - real 3D geometry (6 cuboid elements: grip, shaft, crossbar, 3 angled prongs) - flat 2D icon nahi, actual 3D shape.
- `assets/minecraft/textures/item/god_trident.png` + `.mcmeta` - **animated texture** (6-frame pulsing glow loop on the prongs), Minecraft ke built-in texture-animation system se.
- Item linking **dono formats** me diya gaya hai taaki purane aur naye Minecraft versions dono pe chale:
  - `assets/minecraft/models/item/trident.json` → legacy `custom_model_data` override (pre-1.21.4 servers ke liye).
  - `assets/minecraft/items/trident.json` → naya item-model system (1.21.4+ servers ke liye).
- `pack.png` - pack icon.

Plugin `CustomModelData = 1001` set karta hai apne God Trident item pe - yehi value in dono files me use hui hai, isliye plugin + resource pack ek saath match karte hain automatically. Baaki normal tridents (bina custom model data ke) hamesha vanilla dikhte rahenge.

---

## Install kaise karein

### Client side (aap khud dekhna chahte ho)
1. `GodTrident-ResourcePack.zip` ko copy karo.
2. Minecraft kholo → **Options → Resource Packs → Open Pack Folder**.
3. Zip file ko us folder me paste karo.
4. Minecraft me pack ko "Available" se "Selected" me move karo.

### Server side (sabko dikhe)
Sabse aasan tarika: pack ko kahin publicly host kar do (GitHub releases, apna web host, etc.) aur `server.properties` me daal do:

```properties
resource-pack=https://your-host.com/GodTrident-ResourcePack.zip
resource-pack-sha1=<zip ka SHA1 hash>
require-resource-pack=false
```

SHA1 nikalne ke liye:
```bash
sha1sum GodTrident-ResourcePack.zip
```

(Bina hosting ke bhi chalega - players apne apne client me manually pack install kar sakte hain jaise upar "Client side" me bataya.)

---

## Version compatibility (pack_format)

`pack.mcmeta` me default `pack_format: 46` (Minecraft **1.21.4**) set hai, plus `supported_formats` range (34-64, roughly 1.21 se 1.21.8 tak) taaki nearby versions pe bhi "incompatible" warning na aaye.

Agar phir bhi warning aaye, apne exact Minecraft version ke hisaab se `pack.mcmeta` me `pack_format` number badal do:

| Minecraft version | pack_format |
|---|---|
| 1.20.4 | 22 |
| 1.20.5 - 1.20.6 | 32 |
| 1.21 - 1.21.1 | 34 |
| 1.21.2 - 1.21.3 | 42 |
| 1.21.4 | 46 |
| 1.21.5 | 55 |
| 1.21.6 | 63 |
| 1.21.7 - 1.21.8 | 64 |

(Latest full table hamesha Minecraft Wiki ke "Pack format" page pe milega, kyunki har update me naya number aata hai.)

---

## Customize karna (Blockbench se)

Model geometry hand-written JSON se banayi gayi hai (real cuboids, koi flat icon nahi) - kaam karega, lekin agar hand-position/scale ko pixel-perfect banana ho (first-person/third-person me), sabse aasan tarika hai:

1. [Blockbench](https://www.blockbench.net/) (free tool) me `assets/minecraft/models/item/god_trident.json` open karo.
2. Live preview me dekh ke `display` transforms (translation/rotation/scale) visually adjust karo.
3. Texture (`god_trident.png`) bhi Blockbench/kisi image editor me directly edit kar sakte ho - top half = metal shaft color, bottom half = glow color (animation frames neeche stacked hain, 32x32 har frame).

Glow ka pulse speed change karna ho to `god_trident.png.mcmeta` me `frametime` badal do (chhota number = fast pulse).
